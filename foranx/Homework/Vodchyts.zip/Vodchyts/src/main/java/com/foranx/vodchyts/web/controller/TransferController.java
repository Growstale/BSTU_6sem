package com.foranx.vodchyts.web.controller;

import com.foranx.vodchyts.web.data.Transaction;
import com.foranx.vodchyts.web.dto.TransferRequest;
import com.foranx.vodchyts.web.service.TransferService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class TransferController {

    private final TransferService transferService;

    public TransferController(TransferService transferService) {

        this.transferService = transferService;
    }

    @PostMapping("/transfers")
    public ResponseEntity<?> transfer(@RequestBody TransferRequest request) {
        System.out.println(">>> [TRANSFER] Запрос на перевод от " + request.getFrom() +
                " к " + request.getTo() +
                " суммы: " + request.getAmount());
        transferService.transfer(request.getFrom(), request.getTo(), request.getAmount());
        System.out.println(">>> [TRANSFER] Перевод выполнен успешно");
        return ResponseEntity.ok("The transfer was completed successfully");
    }

    @GetMapping("cards/{cardNumber}/transactions")
    public ResponseEntity<?> getTransactions(@PathVariable String cardNumber,
                                             @RequestParam(name = "limit", defaultValue = "5") int limit) {
        System.out.println(">>> [TRANSACTIONS] Запрос на получение последних " + limit +
                " транзакций по карте: " + cardNumber);
        List<Transaction> transactions = transferService.getLastTransactions(cardNumber, limit);
        System.out.println(">>> [TRANSACTIONS] Найдено транзакций: " + transactions.size());
        return ResponseEntity.ok(transactions);
    }
}

